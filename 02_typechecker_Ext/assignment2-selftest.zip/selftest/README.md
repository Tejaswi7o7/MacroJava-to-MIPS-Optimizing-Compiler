# Assignment 2 self-test

Requires Python 3 and a JDK (java and javac on PATH).

Unzip this bundle beside your submission archive, then run:

    python3 selftest/eval.py cs99b999_P1.tar.gz

Replace cs99b999 with your roll number. Add -v for per-test details:

    python3 selftest/eval.py -v cs99b999_P1.tar.gz

The submission archive must contain cs99b999_P1/P1/P1.java and the other
sources required to build your type checker. Follow the assignment handout
for packaging. Run the command from the directory containing selftest/;
the submission path may also be absolute.

This bundle contains the 10 Assignment 2 TAKE-HOME public tests and their
expected verdicts. It checks compilation, packaging, and type-checker output.
The evaluator is copied unchanged from the course repository.

It does not test the P1a/P1b/P1c lab extensions. Passing these tests does not
establish that your lab extension is correct. No private or hidden tests,
reference solutions, or tests for other assignments are included.
